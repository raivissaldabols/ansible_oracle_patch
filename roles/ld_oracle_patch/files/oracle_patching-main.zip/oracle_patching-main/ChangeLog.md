# Change History

**V1.1.1** - 3rd November 2022
         Luke Davies

* Fixed bug regarding SQL*Plus versions prior to 18 do not report minor versions
* Fixed log bug for one message

**V1.1.0** - 2nd November 2022
         Luke Davies

* Added 4 possible patch names
* Added minor version numbering for RU specific patches
* Add new feature to allow for specific Oracle Home to be used at the command line
* Add new feature to allow patch to be applied to software only
* Add new feature to not download, i.e. no Internet access
* Add new feature to allow for a specific patch file name to be used
* Add new feature to rollback patches
