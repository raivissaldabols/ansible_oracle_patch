# oracle_patching

To run use 

op.sh [ -d ORACLE_SID ] [ -l PatchLocation ] [-yh] <PatchID>

Where 

  -d is the name of the database that you want to patch 
     (*Note* it will also patch any other databases it finds running in that same ORACLE_HOME)

  -l is the directory location where the patches may be found
     (*Note* this can be configured in the config file for easier management)
     
  -y Indicates that you wish to run using the auto response of y
  
  -h Shows the help text
  
  
What it does

1) Tries to find either the patch zip file, the unzipped patch or will attempt to download the patch from MOS
2) Checks the patch is correct for the OS and DB version
3) Checks Opatch versions and if not correct will try to find the opatch patch as either a zip file or tries to download the latest from MOS
4) Checks to see if the inventory is good and backs it up
5) Checks the executables that need to be down to apply the patch and shutdowns them down including database and listener
6) Applies the patch to the ORACLE_HOME
7) Applies the post patch requirements to any database that it found running in that ORACLE_HOME
8) Brings up all the databases that it affected

What it needs 

Requires the following executables 

* lsof
* wget
* curl
* xmlstarlet xmllint
* zip and unzip 

Oracle Linux command to get these packages

sudo yum install lsof wget curl xmlstarlet zip unzip

