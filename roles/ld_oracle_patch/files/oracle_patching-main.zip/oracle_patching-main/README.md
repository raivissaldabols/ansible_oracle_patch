# oracle_patching

To run use 

`op.sh [ -d ORACLE_SID ] [ -l PatchLocation ] [ -n ZippedPatchFile ] [ -o OracleHome ] [-hIsy] <PatchID>`

Where 

  -d is the name of the database that you want to patch 
     (*Note* it will also patch any other databases it finds running in that same ORACLE_HOME)

  -h Shows the help text

  -I switchs off access to the Internet and disables downloads

  -l is the directory location where the patches may be found
     (*Note* this can be configured in the config file for easier management)

  -n is the name of the zipped file that contains the patch

  -o is the name of the Oracle Home to be patched

  -r rolls back the patch rather than applying it

  -s switches on software only patching i.e. does not patch any databases

  -y Indicates that you wish to run using the auto response of y
    
What it does

1) Tries to find either the patch zip file, the unzipped patch or will attempt to download the patch from MOS
2) Checks the patch is correct for the OS and DB version
3) Checks Opatch versions and if not correct will try to find the opatch patch as either a zip file or tries to download the latest from MOS
4) Checks to see if the inventory is good and backs it up
5) Checks the executables that need to be down to apply the patch and shutdowns them down including database and listener
6) Applies the patch to the ORACLE_HOME
7) Applies the post patch requirements to any database that it found running in that ORACLE_HOME
8) Brings up all the databases that it affected

What it needs 

Requires the following executables 

* lsof
* wget
* curl
* xmlstarlet xmllint
* zip and unzip 

Oracle Linux command to get these packages

`$ sudo yum install lsof wget curl xmlstarlet zip unzip`

## Examples

1. Apply patch 34419443 to current database
`$ bin/op.sh 34419443`

2. Apply patch 43319443 to Oracle Home specified. Do software only 
`$ bin/op.sh -s -o /u01/app/oracle/product/19.3.0/db1 43319443`

3. Apply patch 34086870 using patch file p34086870_19000_Generic.zip. Do not download the patch
`$ bin/op.sh -I -n p34086870_19000_Generic.zip 34086870`

4. Rollback patch 34419443 from database ORCL
`$ bin/op.sh -r -d ORCL 34419443`

5. Apply patch 34419443 found in the location /tmp to database ORCL with no prompts 
`$ bin/op.sh -l /tmp -d ORCL -y 34419443`
