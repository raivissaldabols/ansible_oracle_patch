whenever sqlerror exit failure rollback;
set head off
set pages 0
set lines 500
set feed off
set verify off
set trims on
set term off
set echo off

spool &1/do_run_if_mt.sql

SELECT CASE WHEN version >= 12 
            THEN 'spool &1/do_run_if_mt1.sql'||CHR(10)||'SELECT CASE cdb WHEN ''YES'' THEN ''&2'' END FROM v$database;'||CHR(10)||'spool off'||CHR(10)||'set term on'||CHR(10)||'@&1/do_run_if_mt1.sql'
       END
  FROM ( SELECT SUBSTR(version,1,INSTR(version,'.')-1) version
         FROM v$instance
       )
/

spool off

@&1/do_run_if_mt.sql

exit
