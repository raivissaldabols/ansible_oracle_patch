whenever sqlerror exit failure rollback;
set verify off
connect / as sysdba
shutdown &1
exit