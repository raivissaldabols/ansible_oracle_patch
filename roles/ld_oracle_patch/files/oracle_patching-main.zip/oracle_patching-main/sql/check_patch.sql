whenever sqlerror exit failure rollback
set feed off
set pages 0
set lines 200
set trimspool on
set head off
set verify off

connect / as sysdba 

SELECT CASE WHEN action_time = max_action_time AND action = 'APPLY'
            THEN 'YES' 
            WHEN action = 'ROLLBACK'
            THEN 'NO'
            WHEN action IS NULL
            THEN 'NO'
       END
  FROM (
    SELECT action_time
         , max(action_time) OVER ( PARTITION BY patch_id ) max_action_time 
         , action
      FROM dual 
           LEFT OUTER JOIN sys.registry$sqlpatch
                 ON patch_id = &1
                AND status = 'SUCCESS'
    )
 WHERE action IS NULL 
    OR ( action_time = max_action_time AND action in ( 'APPLY', 'ROLLBACK' ));

exit
