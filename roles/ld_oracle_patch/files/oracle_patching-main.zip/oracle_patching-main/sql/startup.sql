whenever sqlerror exit failure rollback;
set verify off
connect / as sysdba
startup &1
exit
