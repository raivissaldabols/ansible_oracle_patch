set lines 160
set pages 500

col component_name for a50
col version   for a15
col status    for a15

prompt
prompt Oracle Registry details
prompt

select comp_name component_name, version , status 
from   dba_registry
/

col action for a20
col version for a20
col description for a40
col action_time for a30

prompt
prompt Oracle Registry History
prompt

select action 
     , version
     , comments||' '||bundle_series description
     , action_time
from   sys.registry$history
order by action_time desc
/

col description for a70

prompt 
prompt Oracle Patch History
prompt

select action 
     , target_version
     , description 
     , action_time
from   sys.registry$sqlpatch
order by action_time desc
/

